package com.slotcolors;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class SlotColorsScreen extends Screen {
    private final Screen parent;

    public SlotColorsScreen(Screen parent) {
        super(Text.literal("Slot Colors"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        SlotColorsConfig cfg = SlotColorsConfig.INSTANCE;
        int cx = width / 2 - 100, y = 50;

        addDrawableChild(new Channel("Rojo", cx, y, () -> cfg.red, v -> cfg.red = v));      y += 24;
        addDrawableChild(new Channel("Verde", cx, y, () -> cfg.green, v -> cfg.green = v)); y += 24;
        addDrawableChild(new Channel("Azul", cx, y, () -> cfg.blue, v -> cfg.blue = v));    y += 24;
        addDrawableChild(new Channel("Transparencia", cx, y, () -> cfg.alpha, v -> cfg.alpha = v)); y += 30;

        addDrawableChild(ButtonWidget.builder(label("Activado", cfg.enabled), b -> {
            cfg.enabled = !cfg.enabled; b.setMessage(label("Activado", cfg.enabled));
        }).dimensions(cx, y, 200, 20).build());
        y += 24;

        addDrawableChild(ButtonWidget.builder(label("Borde", cfg.border), b -> {
            cfg.border = !cfg.border; b.setMessage(label("Borde", cfg.border));
        }).dimensions(cx, y, 200, 20).build());
        y += 24;

        addDrawableChild(ButtonWidget.builder(Text.literal("Quitar todos los slots marcados"), b -> cfg.slots.clear())
                .dimensions(cx, y, 200, 20).build());
        y += 30;

        addDrawableChild(ButtonWidget.builder(Text.literal("Listo"), b -> close())
                .dimensions(cx, y, 200, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "SI" : "NO"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Alt + clic en un slot del inventario para marcarlo"), width / 2, 34, 0xFFAAAAAA);

        // Vista previa
        SlotColorsConfig cfg = SlotColorsConfig.INSTANCE;
        int px = width / 2 + 120, py = 70;
        ctx.fill(px - 1, py - 1, px + 17, py + 17, 0xFF373737);
        ctx.fill(px, py, px + 16, py + 16, 0xFF8B8B8B);
        SlotColorsClient.paint(ctx, px, py);
    }

    @Override
    public void close() {
        SlotColorsConfig.save();
        client.setScreen(parent);
    }

    private static class Channel extends SliderWidget {
        private final String name;
        private final IntConsumer setter;

        Channel(String name, int x, int y, IntSupplier getter, IntConsumer setter) {
            super(x, y, 200, 20, Text.empty(), getter.getAsInt() / 255.0);
            this.name = name;
            this.setter = setter;
            updateMessage();
        }

        @Override protected void updateMessage() {
            setMessage(Text.literal(name + ": " + (int) Math.round(value * 255)));
        }

        @Override protected void applyValue() {
            setter.accept((int) Math.round(value * 255));
        }
    }
}
