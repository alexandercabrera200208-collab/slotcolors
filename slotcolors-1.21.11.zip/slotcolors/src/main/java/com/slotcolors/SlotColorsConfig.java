package com.slotcolors;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.TreeSet;

public class SlotColorsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("slotcolors.json");
    public static SlotColorsConfig INSTANCE = new SlotColorsConfig();

    public boolean enabled = true;
    public int red = 0x55, green = 0xE5, blue = 0xFF; // celeste por defecto
    public int alpha = 110;                            // 0-255
    public boolean border = true;
    /** Indices del PlayerInventory: 0-8 hotbar, 9-35 inventario, 36-39 armadura, 40 offhand */
    public TreeSet<Integer> slots = new TreeSet<>();

    public int fillArgb()   { return (alpha << 24) | (red << 16) | (green << 8) | blue; }
    public int borderArgb() { return (0xFF << 24) | (red << 16) | (green << 8) | blue; }

    public static void load() {
        try (Reader r = Files.newBufferedReader(PATH)) {
            SlotColorsConfig c = GSON.fromJson(r, SlotColorsConfig.class);
            if (c != null) INSTANCE = c;
        } catch (Exception ignored) { /* primera vez: defaults */ }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(PATH)) {
            GSON.toJson(INSTANCE, w);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
