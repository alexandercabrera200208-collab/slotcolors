package com.slotcolors;

import com.slotcolors.mixin.HandledScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class SlotColorsClient implements ClientModInitializer {
    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        SlotColorsConfig.load();

        openMenu = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.slotcolors.menu", GLFW.GLFW_KEY_K, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                client.setScreen(new SlotColorsScreen(client.currentScreen));
            }
        });

        // --- Hotbar (HUD) ---
        HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR,
                Identifier.of("slotcolors", "hotbar"), (ctx, tick) -> {
            SlotColorsConfig cfg = SlotColorsConfig.INSTANCE;
            if (!cfg.enabled) return;
            int w = ctx.getScaledWindowWidth();
            int h = ctx.getScaledWindowHeight();
            for (int i = 0; i < 9; i++) {
                if (cfg.slots.contains(i)) {
                    paint(ctx, w / 2 - 90 + i * 20 + 2, h - 19);
                }
            }
        });

        // --- Pantallas de inventario ---
        ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            if (!(screen instanceof HandledScreen<?> hs)) return;

            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
                SlotColorsConfig cfg = SlotColorsConfig.INSTANCE;
                if (!cfg.enabled) return;
                HandledScreenAccessor acc = (HandledScreenAccessor) hs;
                for (Slot slot : hs.getScreenHandler().slots) {
                    if (slot.inventory instanceof PlayerInventory && cfg.slots.contains(slot.getIndex())) {
                        paint(ctx, acc.slotcolors$getX() + slot.x, acc.slotcolors$getY() + slot.y);
                    }
                }
            });

            // Alt + clic = marcar / desmarcar slot
            ScreenMouseEvents.allowMouseClick(screen).register((s, mx, my, button) -> {
                long window = MinecraftClient.getInstance().getWindow().getHandle();
                boolean alt = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS
                           || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
                if (!alt || button != 0) return true;

                HandledScreenAccessor acc = (HandledScreenAccessor) hs;
                for (Slot slot : hs.getScreenHandler().slots) {
                    if (!(slot.inventory instanceof PlayerInventory)) continue;
                    int sx = acc.slotcolors$getX() + slot.x, sy = acc.slotcolors$getY() + slot.y;
                    if (mx >= sx && mx < sx + 16 && my >= sy && my < sy + 16) {
                        var set = SlotColorsConfig.INSTANCE.slots;
                        if (!set.remove(slot.getIndex())) set.add(slot.getIndex());
                        SlotColorsConfig.save();
                        return false; // cancela el clic normal (no mueve el item)
                    }
                }
                return true;
            });
        });
    }

    static void paint(DrawContext ctx, int x, int y) {
        SlotColorsConfig cfg = SlotColorsConfig.INSTANCE;
        ctx.fill(x, y, x + 16, y + 16, cfg.fillArgb());
        if (cfg.border) {
            int c = cfg.borderArgb();
            ctx.fill(x - 1, y - 1, x + 17, y, c);
            ctx.fill(x - 1, y + 16, x + 17, y + 17, c);
            ctx.fill(x - 1, y, x, y + 16, c);
            ctx.fill(x + 16, y, x + 17, y + 16, c);
        }
    }
}
